-- Creo il database
create database ToysGroup;

-- Creo la tabella category
Create Table Category(
CategoryKey int
, NomeCategoria varchar(30)
, constraint PK_Categories primary key (CategoryKey)
);

-- Creo la tabella product
Create table product(
ProductKey int
, NomeProdotto varchar(30)
, CategoryKey int
, constraint PK_Product primary key (ProductKey)
, constraint FK_Category foreign key (CategoryKey) 
references Category (CategoryKey)
);

-- Creo la tabella Region
Create table Region(
RegionKey int
, NomeRegione varchar(30)
, constraint PK_Region primary key (RegionKey)
);

-- Creo la tabella States
Create table States(
StatesKey int
, NomeStato varchar(30)
, RegionKey int
, constraint PK_States primary key (StatesKey)
, constraint FK_Region foreign key (RegionKey)
references Region (RegionKey)
);

-- Creo la tabella Customer
Create table Customer(
CustomerKey int
, RagioneSociale varchar(30)
, StatesKey int
, constraint PK_Customer primary key (CustomerKey)
, constraint FK_States foreign key (StatesKey)
references States (StatesKey)
);

-- Creo la tabella Sales
Create table Sales(
SalesKey int
, DataOrdine date
, ProductKey int
, Quantita int
, PrezzoArticolo decimal(6,2)
, ImportoTotale decimal (6,2)
, StatesKey int
, constraint PK_Sales primary key (SalesKey)
, constraint FK_Product foreign key (ProductKey)
references Product (ProductKey) 
, constraint FK_States foreign key (StatesKey)
references States (StatesKey) 
);

-- Popolo la Tabella Category

Insert into Category (CategoryKey, NomeCategoria) values
(1, 'Action Figure')
, (2, 'Bambole')
, (3, 'Modellini Auto')
, (4, 'Lego');

-- Popolo la tabella product

insert into product (ProductKey, NomeProdotto, CategoryKey) values
(1, 'Iron Man', 1)
, (2, 'Superman', 1)
, (3, 'Batman', 1)
, (4, 'Barbie estate', 2)
, (5, 'Ken estate', 2)
, (6, 'Barbie inverno', 2)
, (7, 'Ken inverno', 2)
, (8, 'Porsche', 3)
, (9, 'Ferrari', 3)
, (10, 'Lamborghini', 3)
, (11, 'Bugatti', 3)
, (12, 'Mercedes', 3)
, (13, 'Roma', 4)
, (14, 'Parigi', 4)
, (15, 'Londra', 4);

-- Popolo la tabella Region
insert into Region (RegionKey, DescrizioneRegion) values
(1, 'Europa')
, (2, 'Africa')
, (3, 'Asia')
, (4, 'NordAmerica')
, (5, 'SudAmerica')
, (6, 'Oceania');


-- Popolo la tabella states
insert into States (StatesKey, NomeStato, RegionKey) values
(1, 'USA', 4)
,(2, 'Canada', 4)
,(3, 'Italia', 1)
,(4, 'Francia', 1)
,(5, 'Spagna', 1)
,(6, 'Inghilterra', 1)
,(7, 'Egitto', 2)
,(8, 'Marocco', 2)
,(9, 'Cina', 3)
,(10, 'Giappone', 3)
,(11, 'Brasile', 5)
,(12, 'Argentina', 5)
,(13, 'Australia', 6);


-- Popolo la tabella Sales
insert into Sales (SalesKey, DataOrdine, ProductKey, Quantita, PrezzoArticolo, ImportoTotale, StatesKey) values
(1, '2024-07-14', 3 , 10, 10.00, 100.00, 7)
,(2, '2024-07-22', 4 , 20, 8.50, 170.00, 8)
,(3, '2024-07-01', 11, 25, 7.50, 187.50, 10)
,(4, '2024-07-19', 8 ,15, 7.50, 112.50, 7)
,(5, '2024-08-05', 8 ,30, 7.50, 225.00, 4)
,(6, '2024-08-11', 5, 10, 10.00, 100.00, 7)
,(7, '2024-09-15', 15, 10, 50.00, 500.00, 6)
,(8, '2024-09-10', 4, 5, 8.50, 42.50, 1)
,(9, '2024-10-05', 12, 5, 7.50, 37.50, 8)
,(10, '2024-10-30', 1, 25, 10.00, 250.00, 10)
,(11, '2024-10-20', 9, 20, 7.50, 150.00, 8)
,(12, '2024-11-01', 6, 25, 8.50, 212.50, 1)
,(13, '2024-11-12', 4, 15, 8.50, 127.50, 11)
,(14, '2024-12-03', 10, 20, 7.50, 300.00, 7)
,(15, '2024-12-22', 13, 25, 50.00, 1250.00, 9)
,(16, '2025-01-18', 9, 25, 7.50, 187.50, 11)
,(17, '2025-01-22', 10, 25, 7.50, 187.50, 4)
,(18, '2025-01-27', 6, 15, 8.50, 127.50, 13)
,(19, '2025-02-04', 11, 20, 7.50, 300.00, 13)
,(20, '2025-02-12', 1, 10, 10.00, 100.00, 1)
,(21, '2025-02-25', 3, 10, 10.00, 100.00, 1)
,(22, '2025-03-03', 11, 5, 7.50, 37.50, 11)
,(23, '2025-03-18', 3, 5, 10.00, 50.00, 10)
,(24, '2025-04-02', 13, 15, 50.00, 750.00, 8)
,(25, '2025-04-06', 1, 10, 10.00, 100.00, 6);

-- verifico l'unicita` delle primary key di tutte le tabelle
select
CategoryKey
, count(CategoryKey)
from Category
group by CategoryKey
having count(CategoryKey)>1;

select
ProductKey
, count(ProductKey)
from product
group by ProductKey
having count(ProductKey)>1;

select
RegionKey
, count(RegionKey)
from region
group by RegionKey
having count(RegionKey)>1;

select
SalesKey
, count(SalesKey)
from Sales
group by SalesKey
having count(SalesKey)>1;

select
StatesKey
, count(StatesKey)
from states
group by StatesKey
having count(StatesKey)>1;

-- Espongo elenco ordini con Codice Documento, Data, Nome Prodotto, Categoria Prodotto, Nome Stato, Nome Regione di Vendita e Campo Booleano se sono passati più di 180 giorni dalla data vendita o meno

Select
s.SalesKey as NumeroOrdine
, s.DataOrdine as DataOrdine
, p.NomeProdotto as NomeProdotto
, st.NomeStato as Stato
, r.DescrizioneRegion as Regione
, case when 
datediff(current_date(),s.DataOrdine) > 180 then 'True' 
else 'False' 
end as Scadenza
from sales as s
join product as p
on p.ProductKey = s.ProductKey
join category as c
on p.CategoryKey = c.CategoryKey
join states as st
on s.StatesKey = st.StatesKey
join region as r
on st.RegionKey = r.RegionKey
order by DataOrdine
;

-- Espongo elenco Prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito, mostrando Codice Prodotto e Totale Venduto

select
p.ProductKey
, NomeProdotto
, Sum(Quantita) as TotaleVendite2025
from sales as s
join product as p
on s.ProductKey = p.ProductKey
where year(DataOrdine) = (select
							max(year(DataOrdine))
                            from sales)
group by ProductKey
having sum(Quantita) > (select
						avg(QuantitaTotale)
						from (select
								ProductKey
								, Sum(quantita) as QuantitaTotale
								from sales
								where year(DataOrdine) = (select
															max(year(DataOrdine))
															from sales) 
								group by ProductKey) as totale
                         ) 
;

-- Espongo elenco Prodotti venduti e per ognuno il Fatturato totale per Anno
select
p.ProductKey
, NomeProdotto
, Year(DataOrdine)
, Sum(ImportoTotale)
from product as p
join sales as s 
on s.ProductKey = p.ProductKey
group by p.ProductKey, Year(DataOrdine)
order by p.ProductKey;


-- Espongo Fatturato totale per Stato per Anno e ordinarlo per Data e per Fatturato decrescente
select
st.NomeStato
, year(s.DataOrdine)
, sum(ImportoTotale) as FatturatoTotale
from sales as s
join states as st
on s.StatesKey = st.StatesKey
group by st.StatesKey, year(DataOrdine)
order by year(DataOrdine), FatturatoTotale desc;

-- Espongo Categoria più venduta

select
c.CategoryKey
, Sum(ImportoTotale) as TotaleVenduto
from sales as s
join product as p
on p.ProductKey = s.ProductKey
join category as c
on p.CategoryKey = c.CategoryKey
group by CategoryKey
order by TotaleVenduto desc;

-- Espongo Prodotti invenduti in due approcci
-- usando Join
select
p.ProductKey
, Sum(quantita)as NumeroVendite
from product as p
left join sales as s
on p.ProductKey = s.ProductKey
group by ProductKey
having NumeroVendite is null;

select 
ProductKey,
'0' as NumeroVendite 
From Product 
where ProductKey not in(select
						ProductKey
						from sales
                        group by ProductKey);


-- Creo una View su Prodotti esponendo Codice Prodotto, Nome Prodotto e Nome Categoria
create view  VW_Prodotti as(
select
ProductKey as CodiceProdotto
, NomeProdotto
, NomeCategoria
from product as p
join category as c
on c.CategoryKey = p.CategoryKey)
;


-- Creo una View per Informazioni Geografiche
create view VW_Geo as (
select
st.StatesKey
, st.NomeStato
, r.RegionKey
, r.DescrizioneRegion
from states as st
join region as r
on st.RegionKey = r.RegionKey
)
;
